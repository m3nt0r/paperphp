---
title: "Welcome to PaperPHP"
description: "Installation was successful"
---

# Welcome to PaperPHP

Looks like everything is working. 

You can start **creating pages** by adding `.md` files to your `./pages` directory.

## Syntax Examples

- [Basics](examples/basics)
- [Lists](examples/lists)
- [Images](examples/images)
- [Code](examples/code)
- [Tables](examples/tables)
- [YouTube](examples/youtube)

***

Have fun!