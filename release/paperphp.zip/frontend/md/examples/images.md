---
title: "examples / images"
---

# Images

Exclamation mark, followed by brackets wrapping the desired `alt=""` text,
followed by parenthesis for the `src=""` value of the image element.

    ![your alt text](/path/to/the/image.jpg)

![example image](//unsplash.it/800/480/?random&1)


