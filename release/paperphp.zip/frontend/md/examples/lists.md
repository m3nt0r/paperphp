---
title: "examples / lists"
---

## Let's show some lists

Architecto doloribus eius exercitationem quia tempora voluptate! Commodi delectus dicta error ex hic illum impedit itaque

- This is a unordered list
- It has no order
- Maybe

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto doloribus eius exercitationem quia tempora voluptate! 

1. Let's try ordered
2. Counting is fun
3. And gives structure

> You can als nest lists and much more. The syntax is very forgiving and offers a lot of flexibility.
> The both examples above are the most commonly used ones, as they are easy to distinguish.

## Nested lists

1. Let's try nested
   1. Counting is fun
   2. Let's try ordered
   3. Counting is fun
   4. And gives structure
   
2. Carrying on
3. Business as usual
