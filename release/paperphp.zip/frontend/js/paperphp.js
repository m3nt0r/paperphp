// PaperPHP

console.log('hello world');